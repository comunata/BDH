# BD Hospitality Perfect v1

Site premium + portal + admin discret cu 🔒.

Deploy: urcă folderul pe Netlify.


## v3 Smart Calendar
- Calendar custom dark/gold pentru check-in/check-out.
- Date ocupate demo blocate.
- Calcul automat nopți.
- Fără calendar nativ al browserului.


## v3 Loyalty Visible
- Titlul loyalty schimbat din text abstract în beneficiu clar.
- CTA schimbat în „Vezi beneficiile”.


## v4 Calendar Fixed
- Eliminat al doilea rând Check-in / Check-out.
- Reparat NaN nopți.
- Adăugat sumar perioadă: 10 iulie → 13 iulie · 3 nopți.
- Totalul folosește check-in/check-out, nu câmpuri goale vechi.

## v5 Clean Booking
- Eliminată bara statică de rezervare din hero.
- Calendarul smart rămâne doar în formularul real.
- Eliminată dublura Check-in / Check-out.
- Formularul folosește un singur selector de perioadă.


## v6 No Native Calendar
- Eliminat complet `input type=date`.
- Calendarul albastru Android/iOS nu mai poate apărea.
- Rămâne doar calendarul premium custom dark/gold.

## v7 Polish
- Eliminat dateSummary vizibil.
- WhatsApp/email sunt linkuri reale.
- Adăugat meniu hamburger pe mobil.
- Eliminat mesajul care divulga codul demo.
- CTA header mai compact.
- Cardurile camerelor puțin mai compacte.
- Nu există input type=date în HTML.

## v8 Fixed Calendar Admin
- Calendarul custom este forțat să se deschidă peste pagină.
- Eliminat complet input type=date din index.
- Admin are fallback HTML vizibil, deci nu mai rămâne ecran negru.
- Dashboard admin se reconstruiește robust din localStorage/demo.

## v9 JS Fixed
- Refăcut complet assets/app.js curat, fără dubluri.
- Verificat cu node --check.
- Calendarul custom are funcții globale pentru onclick.
- Adminul se randă stabil.
- Eliminat input type=date.

## v10 Routes Fixed
- Eliminat catch-all Netlify `/* /index.html 200`.
- Adăugate doar rute explicite pentru /admin și /portal.
- Scripturile sunt pe căi relative: assets/app.js și ../assets/app.js.
- Verificat: node --check assets/app.js = OK.
- Verificat: nu există input type=date.


## v11 Calendar Stable
- Calendar refăcut cu clase/ID-uri noi bdhCalendar, fără onclick fragil.
- Event listeners atașate în JavaScript după DOMContentLoaded.
- app.js refăcut curat și verificat cu node --check.
- Nu există input type=date.
