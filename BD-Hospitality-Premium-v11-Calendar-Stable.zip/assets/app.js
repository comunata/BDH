
(function(){
  'use strict';

  const rate = 5;
  let lang = localStorage.getItem('bdh_lang') || 'ro';

  const rooms = [
    {ro:'Cameră Standard', en:'Standard Room', price:280, img:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1100&q=85', desc_ro:'Un spațiu cald, liniștit și elegant pentru sejururi scurte, business sau weekend.', desc_en:'A calm and elegant room for short stays, business trips or weekends.'},
    {ro:'Cameră Deluxe', en:'Deluxe Room', price:390, img:'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1100&q=85', desc_ro:'Mai multă lumină, confort ridicat și atmosferă premium pentru relaxare completă.', desc_en:'More light, elevated comfort and a refined atmosphere for complete rest.'},
    {ro:'Suită Family', en:'Family Suite', price:490, img:'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1100&q=85', desc_ro:'Suită spațioasă pentru familii, cu zonă de relaxare și facilități extra.', desc_en:'A generous suite for families, with lounge space and extra amenities.'}
  ];
  const extras = [
    {ro:'Mic dejun', en:'Breakfast', price:55, type:'personNight'},
    {ro:'Cină / persoană', en:'Dinner / person', price:95, type:'person'},
    {ro:'Late check-out', en:'Late check-out', price:80, type:'fixed'},
    {ro:'Pachet romantic', en:'Romantic package', price:250, type:'fixed'}
  ];

  const $ = id => document.getElementById(id);
  const money = v => lang === 'en' ? '€' + Math.round(v / rate) : Math.round(v) + ' RON';
  const alt = v => lang === 'en' ? '≈ ' + Math.round(v) + ' RON' : '≈ €' + Math.round(v / rate);
  const isoDate = d => d.toISOString().slice(0,10);
  function parseDate(v){ if(!v) return null; const d = new Date(v + 'T12:00:00'); return Number.isNaN(d.getTime()) ? null : d; }
  function readDate(id){ return parseDate($(id)?.value); }
  function fmtShort(d){ return d ? String(d.getDate()).padStart(2,'0') + '.' + String(d.getMonth()+1).padStart(2,'0') + '.' + d.getFullYear() : '—'; }
  function fmtLong(d){ const m=['ianuarie','februarie','martie','aprilie','mai','iunie','iulie','august','septembrie','octombrie','noiembrie','decembrie']; return d ? d.getDate() + ' ' + m[d.getMonth()] : '—'; }
  function nightsBetween(a,b){ return (!a || !b || b <= a) ? null : Math.round((b-a)/(1000*60*60*24)); }
  function readReservations(){ try{ const d=JSON.parse(localStorage.getItem('bdh_perfect_res')||'[]'); return Array.isArray(d)?d:[]; }catch(e){ return []; } }
  function saveReservations(list){ localStorage.setItem('bdh_perfect_res', JSON.stringify(list)); }
  function toast(msg){ const t=$('toast'); if(!t) return; t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),3000); }

  let reservations = readReservations();
  if(!reservations.length){
    reservations=[{code:'BDH-2026-091',name:'Radu Andrei',phone:'+40722123456',email:'radu.andrei@email.com',room:'Cameră Deluxe',checkin:'2026-07-10',checkout:'2026-07-13',nights:3,people:2,total:1170,arrival:'',requests:'',status:'Confirmată'}];
    saveReservations(reservations);
  }

  const busyDates = new Set(['2026-07-15','2026-07-16','2026-07-22','2026-07-23','2026-08-03','2026-08-04']);
  const cal = { target:'checkin', month:new Date(2026,6,1), checkin:new Date('2026-07-10T12:00:00'), checkout:new Date('2026-07-13T12:00:00') };

  function syncCal(){
    const ci=readDate('checkin'), co=readDate('checkout');
    if(ci) cal.checkin=ci;
    if(co) cal.checkout=co;
  }
  function isBusyRange(a,b){
    const d = new Date(a);
    while(d < b){
      if(busyDates.has(isoDate(d))) return true;
      d.setDate(d.getDate()+1);
    }
    return false;
  }
  function updatePeriodSummary(){
    const el=$('periodSummary');
    const ci=readDate('checkin'), co=readDate('checkout'), n=nightsBetween(ci,co);
    if(el) el.textContent = (!ci || !co || !n) ? 'Selectează perioada sejurului' : '📅 ' + fmtLong(ci) + ' → ' + fmtLong(co) + ' · ' + n + (n===1?' noapte':' nopți');
  }
  function renderCalendar(){
    const grid=$('bdhDays'); if(!grid) return;
    const months=['ianuarie','februarie','martie','aprilie','mai','iunie','iulie','august','septembrie','octombrie','noiembrie','decembrie'];
    $('bdhMonthTitle').textContent = months[cal.month.getMonth()] + ' ' + cal.month.getFullYear();
    $('bdhCalHint').textContent = cal.target === 'checkin' ? 'Alege check-in' : 'Alege check-out';
    $('bdhIn').textContent = fmtShort(cal.checkin);
    $('bdhOut').textContent = fmtShort(cal.checkout);
    $('bdhNights').textContent = nightsBetween(cal.checkin, cal.checkout) || '—';
    grid.innerHTML='';
    const first=new Date(cal.month.getFullYear(),cal.month.getMonth(),1);
    const offset=(first.getDay()+6)%7;
    const start=new Date(first); start.setDate(first.getDate()-offset);
    const today=new Date(); today.setHours(0,0,0,0);
    for(let i=0;i<42;i++){
      const d=new Date(start); d.setDate(start.getDate()+i);
      const iso=isoDate(d);
      const btn=document.createElement('button');
      btn.type='button'; btn.className='bdh-day'; btn.textContent=d.getDate();
      if(d.getMonth()!==cal.month.getMonth()) btn.classList.add('muted');
      if(d<today) btn.classList.add('disabled');
      if(busyDates.has(iso)) btn.classList.add('busy');
      if(iso===isoDate(cal.checkin)) btn.classList.add('start');
      if(iso===isoDate(cal.checkout)) btn.classList.add('end');
      if(d>cal.checkin && d<cal.checkout) btn.classList.add('range');
      if(!btn.classList.contains('disabled') && !btn.classList.contains('busy')){
        btn.addEventListener('click',()=>selectCalDate(iso));
      }
      grid.appendChild(btn);
    }
  }
  function selectCalDate(iso){
    const selected=new Date(iso+'T12:00:00');
    if(cal.target==='checkin'){
      cal.checkin=selected;
      if(cal.checkout<=cal.checkin || isBusyRange(cal.checkin,cal.checkout)){
        cal.checkout=new Date(cal.checkin); cal.checkout.setDate(cal.checkout.getDate()+1);
        while(busyDates.has(isoDate(cal.checkout))) cal.checkout.setDate(cal.checkout.getDate()+1);
      }
      cal.target='checkout';
    }else{
      if(selected<=cal.checkin){
        cal.checkin=selected; cal.checkout=new Date(selected); cal.checkout.setDate(cal.checkout.getDate()+1);
      }else if(isBusyRange(cal.checkin, selected)){
        toast('Perioada selectată conține zile ocupate.');
        return;
      }else cal.checkout=selected;
    }
    renderCalendar();
  }
  function openCalendar(target){
    cal.target=target||'checkin';
    syncCal();
    cal.month=new Date(cal.checkin.getFullYear(),cal.checkin.getMonth(),1);
    const modal=$('bdhCalendar');
    if(!modal){ toast('Calendarul nu este încărcat.'); return; }
    modal.classList.add('show');
    modal.setAttribute('aria-hidden','false');
    renderCalendar();
  }
  function closeCalendar(){
    const modal=$('bdhCalendar');
    if(modal){ modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); }
  }
  function applyCalendar(){
    if($('checkin')) $('checkin').value=isoDate(cal.checkin);
    if($('checkout')) $('checkout').value=isoDate(cal.checkout);
    if($('checkinText')) $('checkinText').textContent=fmtShort(cal.checkin);
    if($('checkoutText')) $('checkoutText').textContent=fmtShort(cal.checkout);
    updatePeriodSummary(); calc(); closeCalendar();
  }

  function calc(){
    const room=rooms[Number($('room')?.value||0)]||rooms[0];
    const n=nightsBetween(readDate('checkin'),readDate('checkout'))||1;
    const p=Number($('people')?.value||2);
    let extraTotal=0;
    document.querySelectorAll('[data-extra]:checked').forEach(input=>{
      const e=extras[Number(input.dataset.extra)]; if(!e) return;
      extraTotal += e.type==='personNight' ? e.price*p*n : e.type==='person' ? e.price*p : e.price;
    });
    if($('total')) $('total').textContent = money(room.price*n+extraTotal)+' · '+alt(room.price*n+extraTotal);
    updatePeriodSummary();
  }
  function renderRooms(){
    const el=$('rooms'); if(!el) return;
    el.innerHTML=rooms.map((r,i)=>`
      <article class="card"><div class="room-img" style="background-image:url('${r.img}')"></div><div class="card-body"><h4 class="serif">${lang==='en'?r.en:r.ro}</h4><p>${lang==='en'?r.desc_en:r.desc_ro}</p><div class="price">${money(r.price)} <span>/ ${lang==='en'?'night':'noapte'} · ${alt(r.price)}</span></div><div class="chips"><span class="chip">${lang==='en'?'2 guests':'2 persoane'}</span><span class="chip">Wi‑Fi</span><span class="chip">${lang==='en'?'Digital check-in':'Check-in digital'}</span></div><a href="/#rezervare" class="btn gold" onclick="localStorage.setItem('bdh_room','${i}')">${lang==='en'?'Book':'Rezervă'}</a></div></article>`).join('');
  }
  function initBooking(){
    const room=$('room'); if(!room) return;
    room.innerHTML=rooms.map((r,i)=>`<option value="${i}">${lang==='en'?r.en:r.ro} · ${money(r.price)} (${alt(r.price)})</option>`).join('');
    const saved=localStorage.getItem('bdh_room'); if(saved!==null && rooms[Number(saved)]) room.value=saved;
    const wrap=$('extras');
    if(wrap){
      wrap.innerHTML=extras.map((e,i)=>`<label class="extra-row"><input type="checkbox" data-extra="${i}"> ${lang==='en'?e.en:e.ro} — ${money(e.price)} (${alt(e.price)})</label>`).join('');
      wrap.querySelectorAll('input').forEach(i=>i.addEventListener('change',calc));
    }
    room.addEventListener('input',calc); $('people')?.addEventListener('input',calc);
    $('checkinTrigger')?.addEventListener('click',()=>openCalendar('checkin'));
    $('checkoutTrigger')?.addEventListener('click',()=>openCalendar('checkout'));
    calc();
  }
  function book(e){
    e.preventDefault();
    const room=rooms[Number($('room')?.value||0)]||rooms[0];
    const n=nightsBetween(readDate('checkin'),readDate('checkout'))||1;
    const p=Number($('people')?.value||2);
    let extraTotal=0;
    document.querySelectorAll('[data-extra]:checked').forEach(input=>{
      const ex=extras[Number(input.dataset.extra)]; if(!ex) return;
      extraTotal += ex.type==='personNight'?ex.price*p*n:ex.type==='person'?ex.price*p:ex.price;
    });
    const code='BDH-2026-'+Math.floor(100+Math.random()*900);
    const res={code,name:$('name')?.value||'Client',phone:$('phone')?.value||'',email:$('email')?.value||'',room:room.ro,checkin:$('checkin')?.value,checkout:$('checkout')?.value,nights:n,people:p,total:room.price*n+extraTotal,arrival:'',requests:'',status:'Confirmată'};
    const list=readReservations(); list.unshift(res); saveReservations(list);
    if($('createdCode')) $('createdCode').innerHTML='Rezervare confirmată<br>Cod: <b>'+code+'</b><br><a class="btn ghost" href="/portal/?code='+code+'">Intră în portal</a>';
    toast('Rezervare creată: '+code);
  }
  function openPortal(){
    const codeEl=$('portalCode'); if(!codeEl) return;
    const params=new URLSearchParams(location.search); if(params.get('code')) codeEl.value=params.get('code');
    const r=readReservations().find(x=>x.code===codeEl.value.trim());
    if(!r){ toast('Cod negăsit. Verifică datele introduse.'); return; }
    $('portal')?.classList.add('show');
    if($('pClient')) $('pClient').textContent=r.name||'';
    if($('pRoom')) $('pRoom').textContent=r.room||'';
    if($('pTotal')) $('pTotal').textContent=money(r.total||0)+' · '+alt(r.total||0);
    if($('arrival')) $('arrival').value=r.arrival||'';
    if($('requests')) $('requests').value=r.requests||'';
  }
  function savePortal(){
    const code=$('portalCode')?.value.trim(); const list=readReservations(); const r=list.find(x=>x.code===code); if(!r) return;
    r.arrival=$('arrival')?.value||''; r.requests=$('requests')?.value||''; r.status='Check-in online'; saveReservations(list); toast('Check-in trimis către recepție.');
  }
  function updateLoyalty(){
    if(!$('tier')) return;
    const c=readReservations().length, next=c>=10?15:c>=5?10:5, tier=c>=10?'Gold':c>=5?'Silver':'Bronze';
    $('tier').textContent=tier; if($('bar')) $('bar').style.width=Math.min(100,c/next*100)+'%'; if($('loyaltyText')) $('loyaltyText').textContent=`${c}/${next} rezervări până la următorul beneficiu.`;
  }
  function renderAdmin(){
    if(!document.body.classList.contains('admin-page')) return;
    const app=$('adminApp'); if(!app) return;
    if(localStorage.getItem('bdh_admin')!=='1'){
      app.innerHTML=`<div class="login"><div class="eyebrow">Admin demo</div><h1 class="serif" style="font-size:42px;margin:12px 0">Autentificare demo</h1><p style="color:var(--muted)">Acces demonstrativ pentru proprietar, manager și recepție.</p><form id="adminLogin"><label>Email</label><input required value="manager@bdhospitality.ro"><label>Parolă</label><input required type="password" value="demo2026"><button class="btn gold" type="submit">Intră în Dashboard Demo</button></form></div>`;
      $('adminLogin')?.addEventListener('submit',ev=>{ev.preventDefault();localStorage.setItem('bdh_admin','1');renderAdmin();});
      return;
    }
    const list=readReservations(), income=list.reduce((s,r)=>s+Number(r.total||0),0);
    app.innerHTML=`<div class="admin-shell"><aside class="sidebar"><a class="brand" href="/"><div class="logo">BD</div><div><h1>BD Admin</h1><p>Hospitality OS</p></div></a><nav class="admin-nav"><a class="active">Dashboard</a><a>Rezervări</a><a>Camere</a><a>Housekeeping</a><a>Plăți</a><a>Loyalty</a><a>Setări</a></nav><button id="adminLogout" class="btn ghost" style="margin-top:24px;width:100%">Logout</button></aside><main class="admin-main"><div class="eyebrow">Live operations</div><h1 class="serif" style="font-size:48px;margin:12px 0 24px">Dashboard</h1><div class="grid kpis"><div class="kpi">Sosiri azi<strong>${list.length}</strong></div><div class="kpi">Ocupare<strong>72%</strong></div><div class="kpi">Venit<strong>${money(income)}</strong></div><div class="kpi">Task-uri<strong>3</strong></div></div><section style="padding:28px 0;border:0"><h2 class="serif">Rezervări recente</h2><div class="table">${list.slice(0,8).map(r=>`<div class="row"><b>${r.name||'Client'}</b><span>${r.room||'Cameră'}</span><span>${r.code||'BDH'}</span><span class="chip">${r.status||'Confirmată'}</span></div>`).join('')}</div></section></main></div>`;
    $('adminLogout')?.addEventListener('click',()=>{localStorage.removeItem('bdh_admin');renderAdmin();});
  }
  function switchLang(){ lang=lang==='ro'?'en':'ro'; localStorage.setItem('bdh_lang',lang); location.reload(); }
  function toggleMobileMenu(force){ const d=$('mobileDrawer'); if(!d) return; if(force===false){d.classList.remove('show');return;} d.classList.toggle('show'); }

  document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('input[type="date"]').forEach(n=>n.remove());
    renderRooms(); initBooking(); updateLoyalty(); renderAdmin(); updatePeriodSummary();
    $('bdhPrevMonth')?.addEventListener('click',()=>{cal.month=new Date(cal.month.getFullYear(),cal.month.getMonth()-1,1);renderCalendar();});
    $('bdhNextMonth')?.addEventListener('click',()=>{cal.month=new Date(cal.month.getFullYear(),cal.month.getMonth()+1,1);renderCalendar();});
    $('bdhCloseCal')?.addEventListener('click',closeCalendar);
    $('bdhApplyCal')?.addEventListener('click',applyCalendar);
    $('bdhCalendar')?.addEventListener('click',e=>{if(e.target.id==='bdhCalendar') closeCalendar();});
    if($('portalCode')) setTimeout(openPortal,120);
    window.addEventListener('scroll',()=>document.querySelector('.header')?.classList.toggle('solid',scrollY>40));
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeCalendar();});

  window.switchLang=switchLang; window.toggleMobileMenu=toggleMobileMenu; window.book=book; window.openPortal=openPortal; window.savePortal=savePortal; window.calc=calc;
  window.openSmartCalendar=openCalendar; // backward compatibility
})();
